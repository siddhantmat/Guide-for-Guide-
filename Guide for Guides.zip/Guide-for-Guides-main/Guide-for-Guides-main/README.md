# Guide-for-Guides
A Travel-Guide hiring website ideated and implemented at
HACKOWASP 5.0 in Thapar Institute of Engineering and Technology.

THE TEAM:
1) Uttkarsh Singh Pathania (Team Leader)
2) Devansh
3) Siddhant Mathur
4) Aayush Singh
5) Abhimanyu Kumar

THE STORY:
A team of 5 from a point of no return with zero know-how 
of web development tech stack, embarked on this remarkable
journey of building a primarily front-end website for what
they found an interesting idea! 
"A GUIDE FOR GUIDES!"

Tech Stack Used:
1) Frontend: HTML5, CSS3, WebFlow
2) JavaScript for using a Razorpay payment gateway API.

Problems encountered:
1) Familiaring with the concnept and the fundamentals of API.
2) Struggle with fetching RAZORPAY API without extensive know-how of 'Orders' and Advanced Javascript.
3) Difficulties in handling functionalities of links post the push of code to github repository.
